```{r}
# trade-off function
x_max <- 10
y_max <- 10

tradeoff <- function(x) {
  y_max * (exp(1)-exp((x/x_max)^(1/sc))) / (exp(1)- 1)
}
	
sc_s <- 10^seq(-5,2,length=10)
for (i in 1:10) {
	sc <- sc_s[i]
	if (i==1) {
		plot(tradeoff,0, x_max)
	}
	else {
	lines(seq(0,x_max,length=100), tradeoff(seq(0,x_max,length=100)), lty=i)
	}
}
sc <- 1 #  a special case with a near-linear tradeoff
lines(seq(0,x_max,length=100), tradeoff(seq(0,x_max,length=100)), lty=i + 1)
```