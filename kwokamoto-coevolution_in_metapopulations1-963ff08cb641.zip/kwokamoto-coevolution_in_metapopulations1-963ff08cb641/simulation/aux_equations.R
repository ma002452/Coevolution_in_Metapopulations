# Attack rates
a <- function(pathogen_genotype, host_genotype)
	{
	#arms race dynamics
	return(1/(1+exp(-beta*(pathogen_genotype-host_genotype)))) 
	}

# Host tradeoff
cR <- function(x) (1.5+0.01)*(exp(1)-exp(x^sc_host))/(exp(1)-1)  - 1.5 # scaled to go between 0 ,-1.5
R <- c(0.5,resource_diff*0.5)
r <- function(host_genotype, patch_number)
	{
	return(R[patch_number]+cR(host_genotype/nHost_genotypes))
	}

# pathogen tradeoff
cA <- function(x) (0.015-0.005)*(1 - (exp(1)-exp(x^sc_path))/(exp(1)-1) ) + 0.005
e <- function(pathogen_genotype, patch_number)
	{
	return(c_e - cA(pathogen_genotype/nPath_genotypes))
	}

# migration rates; same for both path/host
m <- function(patch_1, patch_2)
	{
	return(migration_rate)
	}

# mutation rates; same for both path/host
mu <- function(genotype_1, genotype_2)
	{
	return(mutRate^(abs(genotype_1 - genotype_2)))
	}

