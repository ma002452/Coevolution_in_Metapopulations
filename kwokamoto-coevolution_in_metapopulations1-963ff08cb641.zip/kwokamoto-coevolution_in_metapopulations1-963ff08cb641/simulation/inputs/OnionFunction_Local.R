# The idea of the onion function is to encapsulate in a single parameter the degree of concavity, linearity and convexity of a function describing a trade-off between two variables x and y

foo <- function(x) (1-exp(x^sc)/exp(1))/(1-1/exp(1))

# Which actually simplifies to:
foo <- function(x) (exp(1)-exp(x^sc))/(exp(1)-1)

scs <- 10^seq(-2,2,length=20)
sc <- scs[1]

plot(foo,0,1)
inputs <- seq(0,1,length=100)
for (i in 2:length(scs))
	{
	sc <- scs[i] 
	lines(inputs, foo(inputs))
	}

onion <- function(x, xmin, xmax)
	{
	xprime <- x/(xmax-xmin)
	foo(xprime)
	}
