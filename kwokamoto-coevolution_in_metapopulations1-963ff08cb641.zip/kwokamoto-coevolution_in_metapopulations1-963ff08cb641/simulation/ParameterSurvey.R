source('ModelEquation.R')

rd <- seq(1.1,25,length=4)
scH <- seq(0.2,3,length=4)
scP <- seq(0.2,3,length=4)
Beta <- seq(0.5,10,length=4)
migr <- 10^(-seq(2,6,length=4))

values <- expand.grid(scH, scP, Beta, rd, migr)

Simulations <- function(sc_host_v, sc_path_v, beta_v, resource_diff_v, migration_rate_v)
	{
	assign("resource_diff", resource_diff_v, envir = .GlobalEnv)
	assign("sc_host", sc_host_v, envir = .GlobalEnv)
	assign("sc_path", sc_path_v, envir = .GlobalEnv)
	assign("beta", beta_v, envir = .GlobalEnv)
	assign("migration_rate", migration_rate_v, envir = .GlobalEnv)

	# migration rates; same for both path/host
	source('aux_equations.R')
	times <- seq(0,1e4,length=1001)
	out <-  lsoda(init, times, model, parms=c(),atol=extinction_Threshold)
	return(out)
	}

#x <- 1
#z <- 1
#p <- Simulations(values[(x-1)*128+z,1],values[(x-1)*128+z,2],values[(x-1)*128+z,3],values[(x-1)*128+z,4],values[(x-1)*128+z,5])

first_negative <- function(population_matrix)
	{
	firstNegs <- rep(0,ncol(population_matrix))
	for (j in 1:ncol(population_matrix))
		{
		# if there are negative elements
		if (length(which(population_matrix[,j] < 0))) 
			{
			firstNegs[j] <- min(which(population_matrix[,j] < -1e-16))
			}
		}
	return(firstNegs)
	}

simOutputs <- list()
x <- 3
for (i in 1:128)
	{
	simOutputs[[i]] <- Simulations(values[(x-1)*128+i,1],values[(x-1)*128+i,2],values[(x-1)*128+i,3],values[(x-1)*128+i,4],values[(x-1)*128+i,5])
	print((x-1)*128+i)
	}
