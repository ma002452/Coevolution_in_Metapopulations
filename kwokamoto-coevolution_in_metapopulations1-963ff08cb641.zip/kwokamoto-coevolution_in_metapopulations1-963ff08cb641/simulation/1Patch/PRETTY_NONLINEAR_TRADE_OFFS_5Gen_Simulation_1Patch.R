require(deSolve)

nPrey_genotypes <- 5
nPred_genotypes <- 5
nPatches <- 2
# Predator background death rate
w <- 1
# patch resource availability
R <- c(0.6,1.5)
k <- c(1e6,1e6)
# cost of resistance
sc_prey <- 0.8
cR <- function(x) (1.5+0.01)*(exp(1)-exp(x^sc_prey))/(exp(1)-1)  - 1.5 # in general, solution is (range * fu - min)
# seq(0.01,-1.5,length=nPrey_genotypes)
r <- function(prey_genotype, patch_number)
	{
	return(R[patch_number]+cR(prey_genotype/nPrey_genotypes))
	}

# attack rates
beta <- 0.5
a <- function(predator_genotype, prey_genotype)
	{
	#arms race dynamics
	hostDefense <- exp(-prey_genotype)
	pathAttack <- exp(beta*predator_genotype)
	return(hostDefense * pathAttack)
	# Phenotypic matching: 
#	return(exp(-beta*(predator_genotype - prey_genotype)^2))
	}

# conversion efficiency/cost of attack
sc_pred <- 0.9
cA <- function(x) (0.015-0.005)*(1 - (exp(1)-exp(x^sc_pred))/(exp(1)-1) ) + 0.005
#cA <- seq(0.005,0.015,length=nPred_genotypes)

c_e <- 0.01
e <- function(predator_genotype, patch_number)
	{
	return(c_e - cA(predator_genotype/nPred_genotypes))
	}

# mutation rates; same for both pred/prey
mutRate <- 10^-1

mu <- function(genotype_1, genotype_2)
	{
	return(mutRate^(abs(genotype_1 - genotype_2)))
	}

# migration rates; same for both pred/prey
migrate <- 0#10^-2

m <- function(patch_1, patch_2)
	{
	return(migrate)
	}

## To generate the equations
#for (i in 1:nPrey_genotypes)
#	for (j in 1:nPatches)
#		{
#		writePrey(i,j)
#		cat('\n')
#		}

## To generate the equations
#for (i in 1:nPred_genotypes)
#	for (j in 1:nPatches)
#		{
#		writePred(i,j)
#		cat('\n')
#		}

model <- function(t, x, parms) {
	with(as.list(c(parms, x)), {
dR1_1 <- r(1,1)*R1_1*(1-R1_1/k[1]-R2_1/k[1]-R3_1/k[1]-R4_1/k[1]-R5_1/k[1])-a(1,1)*C1_1*R1_1-a(2,1)*C2_1*R1_1-a(3,1)*C3_1*R1_1-a(4,1)*C4_1*R1_1-a(5,1)*C5_1*R1_1-mu(1,1)*R1_1 +mu(1,1)*R1_1-mu(1,2)*R1_1 +mu(2,1)*R2_1-mu(1,3)*R1_1 +mu(3,1)*R3_1-mu(1,4)*R1_1 +mu(4,1)*R4_1-mu(1,5)*R1_1 +mu(5,1)*R5_1-m(1,1)*R1_1 +m(1,1)*R1_1 
dR2_1 <- r(2,1)*R2_1*(1-R1_1/k[1]-R2_1/k[1]-R3_1/k[1]-R4_1/k[1]-R5_1/k[1])-a(1,2)*C1_1*R2_1-a(2,2)*C2_1*R2_1-a(3,2)*C3_1*R2_1-a(4,2)*C4_1*R2_1-a(5,2)*C5_1*R2_1-mu(2,1)*R2_1 +mu(1,2)*R1_1-mu(2,2)*R2_1 +mu(2,2)*R2_1-mu(2,3)*R2_1 +mu(3,2)*R3_1-mu(2,4)*R2_1 +mu(4,2)*R4_1-mu(2,5)*R2_1 +mu(5,2)*R5_1-m(1,1)*R2_1 +m(1,1)*R2_1 
dR3_1 <- r(3,1)*R3_1*(1-R1_1/k[1]-R2_1/k[1]-R3_1/k[1]-R4_1/k[1]-R5_1/k[1])-a(1,3)*C1_1*R3_1-a(2,3)*C2_1*R3_1-a(3,3)*C3_1*R3_1-a(4,3)*C4_1*R3_1-a(5,3)*C5_1*R3_1-mu(3,1)*R3_1 +mu(1,3)*R1_1-mu(3,2)*R3_1 +mu(2,3)*R2_1-mu(3,3)*R3_1 +mu(3,3)*R3_1-mu(3,4)*R3_1 +mu(4,3)*R4_1-mu(3,5)*R3_1 +mu(5,3)*R5_1-m(1,1)*R3_1 +m(1,1)*R3_1 
dR4_1 <- r(4,1)*R4_1*(1-R1_1/k[1]-R2_1/k[1]-R3_1/k[1]-R4_1/k[1]-R5_1/k[1])-a(1,4)*C1_1*R4_1-a(2,4)*C2_1*R4_1-a(3,4)*C3_1*R4_1-a(4,4)*C4_1*R4_1-a(5,4)*C5_1*R4_1-mu(4,1)*R4_1 +mu(1,4)*R1_1-mu(4,2)*R4_1 +mu(2,4)*R2_1-mu(4,3)*R4_1 +mu(3,4)*R3_1-mu(4,4)*R4_1 +mu(4,4)*R4_1-mu(4,5)*R4_1 +mu(5,4)*R5_1-m(1,1)*R4_1 +m(1,1)*R4_1 
dR5_1 <- r(5,1)*R5_1*(1-R1_1/k[1]-R2_1/k[1]-R3_1/k[1]-R4_1/k[1]-R5_1/k[1])-a(1,5)*C1_1*R5_1-a(2,5)*C2_1*R5_1-a(3,5)*C3_1*R5_1-a(4,5)*C4_1*R5_1-a(5,5)*C5_1*R5_1-mu(5,1)*R5_1 +mu(1,5)*R1_1-mu(5,2)*R5_1 +mu(2,5)*R2_1-mu(5,3)*R5_1 +mu(3,5)*R3_1-mu(5,4)*R5_1 +mu(4,5)*R4_1-mu(5,5)*R5_1 +mu(5,5)*R5_1-m(1,1)*R5_1 +m(1,1)*R5_1 

dC1_1 <- e(1,1)*(a(1,1)*C1_1*R1_1+a(1,2)*C1_1*R2_1+a(1,3)*C1_1*R3_1+a(1,4)*C1_1*R4_1+a(1,5)*C1_1*R5_1)-mu(1,1)*C1_1 +mu(1,1)*C1_1-mu(1,2)*C1_1 +mu(2,1)*C2_1-mu(1,3)*C1_1 +mu(3,1)*C3_1-mu(1,4)*C1_1 +mu(4,1)*C4_1-mu(1,5)*C1_1 +mu(5,1)*C5_1-m(1,1)*C1_1 +m(1,1)*C1_1-w*C1_1 
dC2_1 <- e(2,1)*(a(2,1)*C2_1*R1_1+a(2,2)*C2_1*R2_1+a(2,3)*C2_1*R3_1+a(2,4)*C2_1*R4_1+a(2,5)*C2_1*R5_1)-mu(2,1)*C2_1 +mu(1,2)*C1_1-mu(2,2)*C2_1 +mu(2,2)*C2_1-mu(2,3)*C2_1 +mu(3,2)*C3_1-mu(2,4)*C2_1 +mu(4,2)*C4_1-mu(2,5)*C2_1 +mu(5,2)*C5_1-m(1,1)*C2_1 +m(1,1)*C2_1-w*C2_1 
dC3_1 <- e(3,1)*(a(3,1)*C3_1*R1_1+a(3,2)*C3_1*R2_1+a(3,3)*C3_1*R3_1+a(3,4)*C3_1*R4_1+a(3,5)*C3_1*R5_1)-mu(3,1)*C3_1 +mu(1,3)*C1_1-mu(3,2)*C3_1 +mu(2,3)*C2_1-mu(3,3)*C3_1 +mu(3,3)*C3_1-mu(3,4)*C3_1 +mu(4,3)*C4_1-mu(3,5)*C3_1 +mu(5,3)*C5_1-m(1,1)*C3_1 +m(1,1)*C3_1-w*C3_1 
dC4_1 <- e(4,1)*(a(4,1)*C4_1*R1_1+a(4,2)*C4_1*R2_1+a(4,3)*C4_1*R3_1+a(4,4)*C4_1*R4_1+a(4,5)*C4_1*R5_1)-mu(4,1)*C4_1 +mu(1,4)*C1_1-mu(4,2)*C4_1 +mu(2,4)*C2_1-mu(4,3)*C4_1 +mu(3,4)*C3_1-mu(4,4)*C4_1 +mu(4,4)*C4_1-mu(4,5)*C4_1 +mu(5,4)*C5_1-m(1,1)*C4_1 +m(1,1)*C4_1-w*C4_1 
dC5_1 <- e(5,1)*(a(5,1)*C5_1*R1_1+a(5,2)*C5_1*R2_1+a(5,3)*C5_1*R3_1+a(5,4)*C5_1*R4_1+a(5,5)*C5_1*R5_1)-mu(5,1)*C5_1 +mu(1,5)*C1_1-mu(5,2)*C5_1 +mu(2,5)*C2_1-mu(5,3)*C5_1 +mu(3,5)*C3_1-mu(5,4)*C5_1 +mu(4,5)*C4_1-mu(5,5)*C5_1 +mu(5,5)*C5_1-m(1,1)*C5_1 +m(1,1)*C5_1-w*C5_1 


	res <- c(dR1_1,dR2_1,dR3_1,dR4_1,dR5_1,dC1_1,dC2_1,dC3_1,dC4_1,dC5_1)
	list(res)
	})
	}

times <- seq(0,5000,length=1001)

y <- init <- c(R1_1=0,R2_1=1,R3_1=0,R4_1=0,R5_1=0,C1_1=0.001,C2_1=0,C3_1=0,C4_1=0,C5_1=0)

parms <- c()
#out <-  ode(init, times, model, parms,method="ode45")
out <-  lsoda(init, times, model, parms,atol=1e-25)
# Get the densities
hostDens1 <- apply(out[,2:6],1,sum)
predDens1 <- apply(out[,7:11],1,sum)
# Get the mean genotypic profiles
uz <- function(x)
	{
	sum(x*(1:5))/sum(x)
	}

hostMean1 <- apply(out[,2:6],1,uz)

predMean1 <- apply(out[,7:11],1,uz)

#par(mfrow=c(1,2),pty="s")
#plot(out[,"R1_1"],t="l",ylim=range(out[,2:21]))
#for (i in 3:21)
#	{
#	lines(out[,i])
#	}

#plot(out[,"C1_1"],t="l",ylim=range(out[,22:41]))
#for (i in 22:41)
#	{
#	lines(out[,i])
#	}

