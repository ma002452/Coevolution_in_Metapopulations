#!/bin/sh
# Submit with qsub
# Tell the SGE that this is an array job, with "tasks" to be numbered 1 to 10000
#$ -t 225001-291600
# When a single command in the array job is sent to a compute node,
# its task number is stored in the variable SGE_TASK_ID,
# so we can use the value of that variable to get the results we want:
#$ -e /home/kwo/krug5838/checkup
#$ -o /home/kwo/krug5838/checkup
module load R
cd /home/kwo/krug5838
Rscript spawn_folders.R $SGE_TASK_ID
