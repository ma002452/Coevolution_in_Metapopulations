require(deSolve)

nPrey_genotypes <- 2
nPred_genotypes <- 2
nPatches <- 2

writePrey <- function(i,j) #For the ith host genotype in the jth patch.
	{
	encounters <- paste(paste('-a(',1:nPred_genotypes,',',i,')*C',paste(1:nPred_genotypes,j,sep="_"),'*R',i,'_',j,sep=""),collapse="")
	density_dependence <- paste('-R',1:nPrey_genotypes,'_',j,'/k[',j,']',sep="",collapse='')
	mutations_in <-
paste('+', paste('mu(',1:nPrey_genotypes, ',',i,')*r(',1:nPrey_genotypes,',',j,')*R',1:nPrey_genotypes,'_',j,'*(1',density_dependence,')',sep='',collapse='+'))
	mutations_out <-
paste('mu(',i, ',',1:nPrey_genotypes,')',sep='',collapse='+')

	migrations <- paste(paste('-m(',j,',',1:nPatches,')*R',i,'_',j,sep=""),
		           paste('+m(',1:nPatches,',',j,')*R',i,'_',1:nPatches,sep=""),
		     collapse='')
	cat(paste('dR',i,'_',j,' <- (1-(',mutations_out,'))*r(',i,',',j,')*R',i,'_',j,'*(1',density_dependence,')', encounters, mutations_in, migrations , sep="",collapse=""))
	}

writePred <- function(i,j) #For the ith pathogen genotype in the jth patch.
	{
	encounters <- paste('a(',i,',',1:nPrey_genotypes,')','*C',i,'_',j,
paste('*R',1:nPrey_genotypes,'_',j,sep=""),collapse="+",sep="")
	mutations <- paste(paste('-mu(',i,',',1:nPred_genotypes,')*C',i,'_',j,sep=""),
		           paste('+mu(',1:nPred_genotypes,',',i,')*C',(1:nPred_genotypes),'_',j,sep=""),
		     collapse="")
	migrations <- paste(paste('-m(',j,',',1:nPatches,')*C',i,'_',j,sep=""),
		           paste('+m(',1:nPatches,',',j,')*C',i,'_',1:nPatches,sep=""),
		     collapse='')
	cat(paste('dC',i,'_',j,' <- e(',i,',',j,')*(', encounters,')', mutations, migrations , '-w*C',i,'_',j, sep="",collapse=""))
	}

preyByPatch <- cbind(rep("dR",nPrey_genotypes * nPatches),expand.grid(1:nPrey_genotypes,'_', 1:nPatches))
predByPatch <- cbind(rep("dC",nPred_genotypes * nPatches),expand.grid(1:nPred_genotypes,'_', 1:nPatches))

listVars <- c(apply(preyByPatch,1,paste,collapse=""), apply(predByPatch,1,paste,collapse=""))
listVars <- gsub(" ","",listVars)
cat(paste("c(",paste(listVars,collapse=","),")",sep=""))


invals <- paste(paste(listVars,collapse="=0,"),"=0",sep="")
invals <- gsub("d","",invals)
for (i in 1:nPatches)
	{
	invals <- gsub(paste("R1","_",i,"=0",sep=""),paste("R1","_",i,"=1",sep=""),invals)
	invals <- gsub(paste("C1","_",i,"=0",sep=""),paste("C1","_",i,"=0.001",sep=""),invals)
	}


for (i in 1:nPrey_genotypes)
	{
	cat(writePrey(i,1),"\n")
	cat(writePrey(i,2),"\n")
	}
for (i in 1:nPred_genotypes)
	{
	cat(writePred(i,1),"\n")
	cat(writePred(i,2),"\n")
	}


# initial values:
invals <- paste(paste(listVars,collapse="=0,"),"=0",sep="")
invals <- gsub("R1_1=0","R1_1=1",invals)
invals <- gsub("C1_1=0","C1_1=0.01",invals)



writePreyJac_vizPrey <- function(i,j,n,k) #Jacobian entry for the ith prey genotype in the jth patch relative to the nth genotype in the kth patch
	{
	if (i==n && j==k)
		{
		opening <- paste('r(',i,',',j,')-2*r(',i,',',j,')*R',i,'_',j,'/k[',j,']',sep="")
		density_dependence <- paste('-r(',i,',',j,')*R',(1:nPrey_genotypes)[-i],'_',j,'/k[',j,']',sep="")
		encounters <-  paste(paste('-a(',1:nPred_genotypes,',',n,')*C',paste(1:nPred_genotypes,n,sep="_"),sep=""),collapse="")
		mutations_in <- paste('+mu(',i,',',i,')',sep="")
		mutations_out <- paste('-mu(',1:nPrey_genotypes,',',i,')',sep="")
		migrations_in <- paste('+m(',j,',',j,')',sep="")
		migrations_out <- paste('-m(',1:nPatches,',',j,')',sep="")
		cat(opening, density_dependence, encounters, mutations_in, mutations_out, migrations_in, migrations_out)
		}
	if (j != k)
		{
		if (i != n)
			{
			cat(0)
			}
		else
			{
			cat(paste('m(',j,',',k,')',sep=""))
			}
		}
	else
		{
		if (i != n)
			{
			cat(paste('-r(',i,',',j,')*R',n,'_',j,'/k[',j,']+mu(',i,',',n,')',sep=""))
			}
		}
	}

writePreyJac_vizPred <- function(i,j,n,k) #Jacobian entry for the ith prey genotype in the jth patch relative to the nth genotype in the kth patch
	{
	if (j != k)
		{
		cat(0)
		}
	else
		{
		cat(paste('-R',i,'_',j,'*a(',i,',',n,')',sep=''))
		}
	}

writePredJac_vizPred <- function(i,j,n,k) #Jacobian entry for the ith consumer genotype in the jth patch relative to the nth genotype in the kth patch
	{
	if (i==n && j==k)
		{
		encounters <-  paste(paste('a(',1:nPrey_genotypes,',',i,')*R',paste(1:nPrey_genotypes,j,sep="_"),sep=""),collapse="+")
		mutations_in <- paste('+mu(',i,',',i,')',sep="")
		mutations_out <- paste('-mu(',1:nPrey_genotypes,',',i,')',sep="")
		migrations_in <- paste('+m(',j,',',j,')',sep="")
		migrations_out <- paste('-m(',1:nPatches,',',j,')',sep="")
		cat(encounters, mutations_in, mutations_out, migrations_in, migrations_out,'-w')
		}
	if (j != k)
		{
		if (i != n)
			{
			cat(0)
			}
		else
			{
			cat(paste('m(',j,',',k,')',sep=""))
			}
		}
	else
		{
		if (i != n)
			{
			cat(paste('mu(',i,',',n,')',sep=""))
			}
		}
	}


writePredJac_vizPrey <- function(i,j,n,k) #Jacobian entry for the ith consumer genotype in the jth patch relative to the nth genotype in the kth patch
	{
	if (j==k)
		{
		cat(paste('C',i,'_',j,'*a(',i,',',j,')',sep=""))
		}
	else
		cat(0)
	}

# To construct the jacobian 

for (p in 1:nPatches)
	{
	for (i in 1:nPrey_genotypes)
		{
		cat('\n')
		for (v in 1:nPatches)
			{
			for (j in 1:nPrey_genotypes)
				{
				#print(c(i,p,j,v))
				writePreyJac_vizPrey(i,p,j,v)
				cat(', ')
				}
			for (j in 1:nPred_genotypes)
				{
				writePreyJac_vizPred(i,p,j,v)
				cat(', ')
				}
			}
		}
	}


for (p in 1:nPatches)
	{
	for (i in 1:nPred_genotypes)
		{
		cat('\n')
		for (v in 1:nPatches)
			{
			for (j in 1:nPrey_genotypes)
				{
				#print(c(i,p,j,v))
				writePredJac_vizPrey(i,p,j,v)
				cat(', ')
				}
			for (j in 1:nPred_genotypes)
				{
				writePredJac_vizPred(i,p,j,v)
				cat(', ')
				}
			}
		}
	}

# From CompetitionColonization_Simulation.R

# In essence, this simulation shows that the r/K trade-off can sustain a competition-colonization trade-off situation under high disturbance settings.

# Based on fitting the logistic model in FitModel_MultipleReplicates_Logistic.R
A11 <- 1/0.022833
A22 <- 1/0.010375


R1 <- 1.2898
R2 <- 2.9236


alpha11 <- function(x)
	{
	A11
	}

alpha12 <- function(x)
	{
	A11
	}

alpha22 <- function(x)
	{
	A22
	}

alpha21 <- function(x)
	{
	A22
	}

r1 <- function(x)
	{
	R1
	}

r2 <- function(x)
	{
	R2
	}

modified_invals <- function(patch_index)
	{
	cat(paste('R11',patch_index,'=as.numeric(invals[\"R11',patch_index,'\"]), ',sep=""), paste('R21',patch_index,'=as.numeric(invals[\"R21',patch_index,'\"]),',sep=""))
	}

# Since we have only one genotype
modified_dvar <- function(i)
	{
	cat(paste(',dR11',i,sep=""),paste(', dR21',i,sep=""))
	}

simulate_day <- function(M, invals, Days)
	{
	parms <- c(m=M)
	metapop_model <- with(as.list(parms), function(t, x, parms) 
		{
		dR111 <- r1(1)*x["R111"]*(1-alpha11(1)* (x["R111"]) - alpha12(1)*(x["R211"])) + (m/9)*(x["R112"]+x["R113"]+x["R114"]+x["R115"]+x["R116"]+x["R117"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R111"] 
		dR112 <- r1(1)*x["R112"]*(1-alpha11(1)* (x["R112"]) - alpha12(1)*(x["R212"])) + (m/9)*(x["R111"]+x["R113"]+x["R114"]+x["R115"]+x["R116"]+x["R117"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R112"] 
		dR113 <- r1(1)*x["R113"]*(1-alpha11(1)* (x["R113"]) - alpha12(1)*(x["R213"])) + (m/9)*(x["R111"]+x["R112"]+x["R114"]+x["R115"]+x["R116"]+x["R117"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R113"] 
		dR114 <- r1(1)*x["R114"]*(1-alpha11(1)* (x["R114"]) - alpha12(1)*(x["R214"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R115"]+x["R116"]+x["R117"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R114"] 
		dR115 <- r1(1)*x["R115"]*(1-alpha11(1)* (x["R115"]) - alpha12(1)*(x["R215"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R114"]+x["R116"]+x["R117"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R115"] 
		dR116 <- r1(1)*x["R116"]*(1-alpha11(1)* (x["R116"]) - alpha12(1)*(x["R216"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R114"]+x["R115"]+x["R117"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R116"]
		dR117 <- r1(1)*x["R117"]*(1-alpha11(1)* (x["R117"]) - alpha12(1)*(x["R217"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R114"]+x["R115"]+x["R116"]+x["R118"]+x["R119"]+x["R1110"]) - m*x["R117"]
		dR118 <- r1(1)*x["R118"]*(1-alpha11(1)* (x["R118"]) - alpha12(1)*(x["R218"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R114"]+x["R115"]+x["R116"]+x["R117"]+x["R119"]+x["R1110"]) - m*x["R118"] 
		dR119 <- r1(1)*x["R119"]*(1-alpha11(1)* (x["R119"]) - alpha12(1)*(x["R219"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R114"]+x["R115"]+x["R116"]+x["R117"]+x["R118"]+x["R1110"]) - m*x["R119"]
		dR1110 <- r1(1)*x["R1110"]*(1-alpha11(1)* (x["R1110"]) - alpha12(1)*(x["R2110"])) + (m/9)*(x["R111"]+x["R112"]+x["R113"]+x["R114"]+x["R115"]+x["R116"]+x["R117"]+x["R118"]+x["R119"]) - m*x["R1110"] 


		dR211 <- r2(1)*x["R211"]*(1-alpha21(1)* (x["R111"]) - alpha22(1)*(x["R211"])) + (m/9)*(x["R212"]+x["R213"]+x["R214"]+x["R215"]+x["R216"]+x["R217"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R211"]
		dR212 <- r2(1)*x["R212"]*(1-alpha21(1)* (x["R112"]) - alpha22(1)*(x["R212"])) + (m/9)*(x["R211"]+x["R213"]+x["R214"]+x["R215"]+x["R216"]+x["R217"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R212"]
		dR213 <- r2(1)*x["R213"]*(1-alpha21(1)* (x["R113"]) - alpha22(1)*(x["R213"])) + (m/9)*(x["R211"]+x["R212"]+x["R214"]+x["R215"]+x["R216"]+x["R217"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R213"]
		dR214 <- r2(1)*x["R214"]*(1-alpha21(1)* (x["R114"]) - alpha22(1)*(x["R214"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R215"]+x["R216"]+x["R217"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R214"]
		dR215 <- r2(1)*x["R215"]*(1-alpha21(1)* (x["R115"]) - alpha22(1)*(x["R215"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R214"]+x["R216"]+x["R217"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R215"]
		dR216 <- r2(1)*x["R216"]*(1-alpha21(1)* (x["R116"]) - alpha22(1)*(x["R216"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R214"]+x["R215"]+x["R217"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R216"]
		dR217 <- r2(1)*x["R217"]*(1-alpha21(1)* (x["R117"]) - alpha22(1)*(x["R217"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R214"]+x["R215"]+x["R216"]+x["R218"]+x["R219"]+x["R2110"]) - m*x["R217"]
		dR218 <- r2(1)*x["R218"]*(1-alpha21(1)* (x["R118"]) - alpha22(1)*(x["R218"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R214"]+x["R215"]+x["R216"]+x["R217"]+x["R219"]+x["R2110"]) - m*x["R218"]
		dR219 <- r2(1)*x["R219"]*(1-alpha21(1)* (x["R119"]) - alpha22(1)*(x["R219"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R214"]+x["R215"]+x["R216"]+x["R217"]+x["R218"]+x["R2110"]) - m*x["R219"]
		dR2110 <- r2(1)*x["R2110"]*(1-alpha21(1)* (x["R1110"]) - alpha22(1)*(x["R2110"])) + (m/9)*(x["R211"]+x["R212"]+x["R213"]+x["R214"]+x["R215"]+x["R216"]+x["R217"]+x["R218"]+x["R219"]) - m*x["R2110"]

		res <- c(dR111, dR112, dR113, dR114, dR115, dR116, dR117, dR118, dR119, dR1110, dR211, dR212, dR213, dR214, dR215, dR216, dR217, dR218, dR219, dR2110)
		list(res)
		})
	init <- c(R111=as.numeric(invals["R111"]),  R112=as.numeric(invals["R112"]),  R113=as.numeric(invals["R113"]),  R114=as.numeric(invals["R114"]),  R115=as.numeric(invals["R115"]),  R116=as.numeric(invals["R116"]),  R117=as.numeric(invals["R117"]),  R118=as.numeric(invals["R118"]),  R119=as.numeric(invals["R119"]),  R1110=as.numeric(invals["R1110"]),  R211=as.numeric(invals["R211"]), R212=as.numeric(invals["R212"]), R213=as.numeric(invals["R213"]), R214=as.numeric(invals["R214"]), R215=as.numeric(invals["R215"]), R216=as.numeric(invals["R216"]), R217=as.numeric(invals["R217"]), R218=as.numeric(invals["R218"]), R219=as.numeric(invals["R219"]), R2110=as.numeric(invals["R2110"]))
	times <- seq(0,24*Days,length=500)
	otpt <- lsoda(y=init, times, metapop_model, parms,rtol=1e-12)
	otpt
	}

#Days <- 0.4
# Start at 1% of carrying capacity


#Bi <- simulate_day(0.01,c(R111=0, R211=0.01*1/A22, R112=0, R212=0.01*1/A22, R113=0, R213=0.01*1/A22, R114=0, R214=0.01*1/A22, R115=0.01*1/A11, R215=0.01*1/A22, R116=0, R216=0.01*1/A22, R117=0, R217=0.01*1/A22, R118=0, R218=0.01*1/A22, R119=0, R219=0.01*1/A22, R1110=0, R2110=0.01*1/A22))

#set.seed(50)

extinction_rate <- 0.5 # set < 1, e.g., 0.975, to permit short-term coexistence.
migration_rate <- 1 # There will always be a migrant from patches

# Fraction of the population that migrates
SerTran <- 0.5

migFrac1 <- 0.01
migFrac2 <- 0.1

TotTime <- 10

# For a local migration event
simulate_migration_event <- function(popSizes, simulated_migration)
	{
	migMatrix <- matrix(0, 10, 10)
	source_pops <- which(simulated_migration > 0)
	if (length(source_pops) > 0)
		{
		for (i in 1:length(source_pops))
			{
			destPop <- sample((1:10)[-source_pops[i]],1)
			migMatrix[source_pops[i], destPop] <- migFrac
			}
		}
	return(c(popSizes[1:10]%*%migMatrix, popSizes[11:20]%*%migMatrix))
	}

# For a global migration event
# There will always be a migrant from patches
simulate_Globalmigration_event <- function(popSizes, migFrac)
	{
	migMatrix <- matrix(0, 10, 10)
	source_pops <- 1:10
	if (length(source_pops) > 0)
		{
		for (i in 1:length(source_pops))
			{
			migMatrix[source_pops[i], 1:10] <- migFrac/10
			}
		}
	return(popSizes%*%migMatrix)
	}

check_coex <- function(TotTime)
	{
	Bi <- simulate_day(0.0,c(R111=0, R211=0, R112=0, R212=0, R113=0, R213=0, R114=0, R214=0, R115=1/A11, R215=1/A22, R116=0, R216=0, R117=0, R217=0, R118=0, R218=0, R119=0, R219=0, R1110=0, R2110=0), Days)
	B <- Bi
	for (i in 1:TotTime)
		{
		ext_sim <- rbinom(10, 1, 1-extinction_rate)

		mig_sim <- rbinom(10, 1, migration_rate)

		# Simulate serial transfer
		newPop <- Bi[nrow(Bi),2:21]*SerTran
		
		# Simulate extinction		
		newPop <- Bi[nrow(Bi),2:21]*c(ext_sim,ext_sim)
		# if species 2 is not subject to extinction:
		#newPop <- Bi[nrow(Bi),2:21]*c(ext_sim,rep(1,10))

		# Simulate migration
		newPop[1:10] <- newPop[1:10] + simulate_Globalmigration_event(Bi[nrow(Bi),2:11], migFrac1)
		newPop[11:20] <- newPop[11:20] + simulate_Globalmigration_event(Bi[nrow(Bi),12:21], migFrac2)
		
		Bi <- simulate_day(0.0, newPop, Days)
		B <- rbind(B, Bi)
		print(i)
		}
	return(B)
	}

# In the absence of migration, this causes species two, the inferior competitor, to dominate:
#g <- check_coex(0.1)

extinction_rate <- 0.975
migration_rate <- 0.9
migFrac <- 0.01
Days <- 0.1
SerTran <- 0.1

check_coex_altinit <- function(TotTime, extinction_rate, migration_rate, migFrac, Days, SerTran)
	{
	Bi <- simulate_day(0.0,c(R111=0, R211=0, R112=0, R212=0, R113=0, R213=0, R114=0, R214=0, R115=0.01*1/A11, R215=0.01*1/A22, R116=0, R216=0, R117=0, R217=0, R118=0, R218=0, R119=0, R219=0, R1110=0, R2110=0), Days)
	B <- Bi

	simulate_migration_event <- function(popSizes, simulated_migration)
		{
		migMatrix <- matrix(0, 10, 10)
		source_pops <- which(simulated_migration > 0)
		if (length(source_pops) > 0)
			{
			for (i in 1:length(source_pops))
				{
				destPop <- sample((1:10)[-source_pops[i]],1)
				migMatrix[source_pops[i], destPop] <- migFrac
				}
			}
		return(c(popSizes[1:10]%*%migMatrix, popSizes[11:20]%*%migMatrix))
		}

	for (i in 1:TotTime)
		{
		ext_sim <- rbinom(10, 1, 1-extinction_rate)

		mig_sim <- rbinom(10, 1, migration_rate)

		# Simulate serial transfer
		newPop <- Bi[nrow(Bi),2:21]*SerTran

		# Simulate extinction
		newPop <- newPop*c(ext_sim,ext_sim)
		# if species 2 is not subject to extinction:
		#newPop <- Bi[nrow(Bi),2:21]*c(ext_sim,rep(1,10))
		
		# Simulate migration
		newPop <- newPop + simulate_migration_event(Bi[nrow(Bi),2:21], mig_sim)
		
		Bi <- simulate_day(0.0, newPop, Days)
		B <- rbind(B, Bi)
		print(i)
		}
	return(B)
	}

ji <- check_coex_altinit(250, extinction_rate = 0.5, migration_rate = 0.9, migFrac = 0.01, Days = 0.1, SerTran = 0.2)

# Note if you simulate serial transfer after simulating extinction, so that only a fraction are serially transfered, you actually get coexistence.

####################
#		newPop <- Bi[nrow(Bi),2:5]*c(ext_sim,ext_sim)
		# if species 2 is not subject to extinction:
		#newPop <- Bi[nrow(Bi),2:21]*c(ext_sim,rep(1,10))
		# Simulate serial transfer
#		newPop <- newPop + Bi[nrow(Bi),2:5]*SerTran
###################

# I actually think this ^^ is a manifestation of the storage effect. What's going on is that a fraction of the inferior competitors are able to persist despite an extinction event. It's not an irrelevant result, as you might still get extinction in this model, but maybe this isn't all that germaine.

#ji <- check_coex_altinit(500, extinction_rate = 0.975, migration_rate = 0.9, migFrac = 0.01, Days = 0.1, SerTran = 0.1)

#ji <- check_coex_altinit(5000)

# validate that long-term coexistence occurs:
if (FALSE)
{
TotTime <- 1e5
Bi <- simulate_day(0.0,c(R111=0, R211=0, R112=0, R212=0, R113=0, R213=0, R114=0, R214=0, R115=0.01*1/A11, R215=0.01*1/A22, R116=0, R216=0, R117=0, R217=0, R118=0, R218=0, R119=0, R219=0, R1110=0, R2110=0), Days)
	B <- Bi
	for (i in 1:TotTime)
		{
		ext_sim <- rbinom(10, 1, 1-extinction_rate)

		mig_sim <- rbinom(10, 1, migration_rate)

		newPop <- Bi[nrow(Bi),2:21]*c(ext_sim,ext_sim)
		# if species 2 is not subject to extinction:
		#newPop <- Bi[nrow(Bi),2:21]*c(ext_sim,rep(1,10))
		# Simulate serial transfer
		newPop <- newPop + Bi[nrow(Bi),2:21]*SerTran
		
		# Simulate migration
		newPop <- newPop + simulate_migration_event(Bi[nrow(Bi),2:21], mig_sim)
		
		Bi <- simulate_day(0.0, newPop, Days)
		#write.table(Bi, file="longTermCheck.txt", append=TRUE,col.names=F,row.names=F)
		B <- rbind(B, Bi)
		print(i)
		}
}
