```{r}
library(dde)

RC <- function(t, y, p) {
  r <- 0.5
  k <- 0.5
  x <- 1
  phi <- 1
  gamma <- 0.5
  t_latent <- 5
  d <- 0.1
  
  R <- y[[1L]]
  C <- y[[2L]]

  tau <- t - t_latent
  y_lag <- dde::ylag(tau, c(1L, 2L)) # Here is ylag!
  R_lag <- y_lag[[1L]]
  C_lag <- y_lag[[2L]]

  c(r * R * (1 - R/k) - x/phi * C * R,
    gamma * x/phi * C_lag * R_lag - d * C)
}

y0 <- c(1, 1)
tt <- seq(0, 365, length.out = 100)
yy <- dde::dopri(y0, tt, RC, NULL, n_history = 1000L, return_history = FALSE)
plot(log(yy[,3]),type='l')
```