rd <- seq(1.1,25,length=4)
scH <- seq(0.2,3,length=4)
scP <- seq(0.2,3,length=4)
Beta <- seq(0.5,10,length=4)
migr <- 10^(-seq(2,6,length=4))
values <- expand.grid(scH, scP, Beta, rd, migr)
colnames(values) <- c("scH", "scP", "Beta", "rd", "migr")
noMigvalues <- cbind(expand.grid(scH, scP, Beta, rd),rep(0,4^4))
colnames(noMigvalues) <- c("scH", "scP", "Beta", "rd", "migr")
values <- rbind(noMigvalues,values)

simOutputs <- readRDS("SimulationResult_BroadParameterSurvey.RData")
baseline <- readRDS("NoMig_SimulationResult_BroadParameterSurvey.RData")
simOutputs <- append(baseline, simOutputs)

calcStuff <- function(out)
	{
	hostDens1 <- apply(out[,2:6],1,sum)
	hostDens2 <- apply(out[,7:11],1,sum)

	predDens1 <- apply(out[,12:16],1,sum)
	predDens2 <- apply(out[,17:21],1,sum)

	# Get the mean genotypic profiles
	uz <- function(x)
		{
		sum(x*(1:5))/sum(x)
		}

	hostMean1 <- apply(out[,2:6],1,uz)
	hostMean2 <- apply(out[,7:11],1,uz)

	predMean1 <- apply(out[,12:16],1,uz)
	predMean2 <- apply(out[,17:21],1,uz)

	return(cbind(hostDens1, hostDens2, predDens1, predDens2, hostMean1, hostMean2, predMean1, predMean2))
	}

normalize <- function(y)
	{
	# Identify the row of the parameter matrix values without a migrant to which the row y corresponds
	NoMigrant_row <- which(apply(values[1:256,1:4],1,function(x) all(x[1:4]==values[y,1:4]))==TRUE)
	results <- calcStuff(simOutputs[[y]])
	resultsNoMig <- calcStuff(simOutputs[[NoMigrant_row]])
	normalized <- results/resultsNoMig
	return(normalized)
	}

z <- function(x,y)
	{
	par(mfrow=c(8,8),mar=c(0,0,0,0))
	for (i in x)
		{
		ans <- normalize(i)
		plot(ans[,y],t="l",axes=F)
		text(rep(500,5),seq(0.6,0.95,length=5)*max(ans[,y],na.rm=T),paste(c("scH", "scP", "Beta", "rd", "migr"),round(c(as.numeric(values[i,1:4]),log(values[i,5],10)),2),sep="="),cex=1)
		}
	}

starts <- seq(1,1280,64)
ends <- seq(64,1280,64)
v <- 1
z(starts[v]:ends[v],1)

# To begin, naively look at coefficients of variations for last 2000 time steps:
cvs <- numeric()
calcCV <- function(x)
	{
	otcm <- normalize(x)
	finvals <- otcm[800:1001,1]
	return(sd(finvals)/mean(finvals))
	}

cvs <- sapply(1:1280,calcCV)
for (y in 1:1280)
	{
	otcm <- normalize(y)
	finvals <- otcm[800:1001,1]
	cvs[y] <- sd(finvals)/mean(finvals)
	}
