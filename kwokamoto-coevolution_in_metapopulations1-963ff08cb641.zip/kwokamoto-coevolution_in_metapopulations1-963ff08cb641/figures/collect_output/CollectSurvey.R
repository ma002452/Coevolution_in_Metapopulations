rd <- seq(1.1,25,length=4)
scH <- seq(0.2,3,length=4)
scP <- seq(0.2,3,length=4)
Beta <- seq(0.5,10,length=4)
migr <- 10^(-seq(2,6,length=4))

values <- expand.grid(scH, scP, Beta, rd, migr)
colnames(values) <- c("scH", "scP", "Beta", "rd", "migr")

simOutputs <- list()

k <- 1
for (i in 1:8)
	{
	x <- readRDS(paste("Survey",i,".RData",sep=""))
	for (m in 1:length(x))
		{
		simOutputs[[k]] <- x[[m]]
		k <- k+1
		}
	}


calcStuff <- function(out)
	{
	hostDens1 <- apply(out[,2:6],1,sum)
	hostDens2 <- apply(out[,7:11],1,sum)

	predDens1 <- apply(out[,12:16],1,sum)
	predDens2 <- apply(out[,17:21],1,sum)

	# Get the mean genotypic profiles
	uz <- function(x)
		{
		sum(x*(1:5))/sum(x)
		}

	hostMean1 <- apply(out[,2:6],1,uz)
	hostMean2 <- apply(out[,7:11],1,uz)

	predMean1 <- apply(out[,12:16],1,uz)
	predMean2 <- apply(out[,17:21],1,uz)

	return(cbind(hostDens1, hostDens2, predDens1, predDens2, hostMean1, hostMean2, predMean1, predMean2))
	}

z <- function(x,y)
	{
	par(mfrow=c(8,8),mar=c(0,0,0,0))
	for (i in x)
		{
		ans <- calcStuff(simOutputs[[i]])
		plot(ans[,y],t="l",axes=F)
		text(rep(500,5),seq(0.6,0.95,length=5)*max(ans[,y],na.rm=T),paste(c("scH", "scP", "Beta", "rd", "migr"),round(c(as.numeric(values[i,1:4]),log(values[i,5],10)),2),sep="="),cex=1)
		}
	}

starts <- seq(1,1024,64)
ends <- seq(64,1024,64)

v <- 1
z(starts[v]:ends[v],1)
