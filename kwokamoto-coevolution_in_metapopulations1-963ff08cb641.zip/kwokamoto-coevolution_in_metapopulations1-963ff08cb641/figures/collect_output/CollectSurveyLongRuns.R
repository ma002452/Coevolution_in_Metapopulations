
rd <- seq(2,25,length=15)
scH <- seq(0.8,2,length=2)
scP <- seq(0.8,2,length=2)
Beta <- seq(1,10,length=4)
migr <- c(0,10^(-seq(2.5,6,length=15)))

values <- expand.grid(scH, scP, Beta, rd, migr)

colnames(values) <- c("scH", "scP", "Beta", "rd", "migr")

simOutputs <- list()

k <- 1
partitions <- c("LongSet1.RData","LongSet2.RData","LongSet3.RData","LongSet4.RData","LongSet5.RData","LongSet5b.RData", "LongResults_6a.RData", "LongResults_6b.RData","LongResults_6c.RData","LongResults_6d.RData")
for (i in 1:length(partitions))
	{
	x <- readRDS(partitions[i])
	for (m in 1:length(x))
		{
		simOutputs[[k]] <- x[[m]]
		k <- k+1
		}
	}

