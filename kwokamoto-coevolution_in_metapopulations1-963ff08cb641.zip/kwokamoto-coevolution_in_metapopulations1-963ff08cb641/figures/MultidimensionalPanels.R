readRDS("/Users/NguyenTran/Downloads/simOutput.RData")
readRDS("/Users/NguyenTran/Downloads/NoMig_SimulationResult_BroadParameterSurvey.RData")

calcCV <- function(x)
{
otcm <- normalize(x)
finvals <- otcm[8000:10001,'predDens1']
return(sd(finvals)/mean(finvals))
}
cvs <- sapply(1:nrow(values),calcCV)


findCombo <- function(x)
{
sch <- which(values[,'scH']==x[1])
scp <- which(values[sch,'scP']==x[2])
bets <- which(values[sch[scp],'Beta']==x[3])
return(sch[scp[bets]])
}

reorganizeCVS <- function(cvs)
  {
  noMigrs <- cvs[1:15]
  cvs <- c(cvs[-(1:15)], noMigrs)
  return(cvs)
  }

drawCombos <- function(x)
  {
  # Because migr is originally defined to start with zero, to make it simpler have the zero migration scenario at the end
  newMigrs <- c(migr[-1],0)
  perms <- findCombo(x)
  zvals <- reorganizeCVS(cvs[perms])
  z <- matrix (zvals, ncol=16)
  par(las=1,mar=c(5,6.5,4,1))
  image.plot(x=rd,z=z,zlim=c(0,4),axes=F,xlab="Resource differential between habitats",cex.lab=1.5, main="Coefficients of Variation",cex.main=2)
  axis(1,cex.axis=1.5)
  axis(2,at=seq(0,1,length=6),labels=log(newMigrs[seq(1,16,length=6)],10),cex.axis=1.5)
  par(las=0)
  mtext(expression('Log'[10]~'Migration rate'),side=2,cex=1.5,line=4)
  }
drawCombos(c(0.8,2,10))


