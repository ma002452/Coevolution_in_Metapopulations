```{r}
library(deSolve); library(dplyr)

parameters <- c(R_i = 0.01, K_i = 1000000)
state <- c(N_i = 1)
times <- seq(0, 10000, by = 1)

ROC_popSize <- function(t, state, parameters) {
  with(as.list(c(parameters, state)), {
  # rate of change for a population size N_i(t) of animals of type i that have finite resources
  dN_i <- parameters['R_i'] * state['N_i'] * (1 - state['N_i'] / parameters['K_i'])
  list(dN_i)
  })
}

output <- lsoda(y = state, times = times, func = ROC_popSize, parms = parameters)
head(output)

plot(output, type="l")
```