```{r}
# trade-off function
x_max <- 10
y_max <- 10

tradeoff <- function(x) {
  y_max * (exp(1)-exp((x/x_max)^(1/sc))) / (exp(1)- 1)
}
	
sc_s <- 10^seq(-5,2,length=10)
for (i in 1:10) {
	sc <- sc_s[i]
	if (i==1) {
		plot(tradeoff,0, x_max)
	}
	else {
	lines(seq(0,x_max,length=100), tradeoff(seq(0,x_max,length=100)), lty=i)
	}
}
sc <- 1 #  a special case with a near-linear tradeoff
lines(seq(0,x_max,length=100), tradeoff(seq(0,x_max,length=100)), lty=i + 1)


# Resource&Consumer model (nPatches=2, nPrey_genotypes=1, nPred_genotypes=1)
RC <- function(t, y, p) {
    k <- 1
    x <- 1
    phi <- 1
    r <- tradeoff(phi)
    gamma <- 0.1
    t_latent <- 1
    d <- 0.01
    e <- 0.5
    l <- 0.5
    
    R1 <- y[[1L]]
    C1 <- y[[2L]]
    R2 <- y[[3L]]
    C2 <- y[[4L]]
  
    tau <- t - t_latent
    y_lag <- dde::ylag(tau, c(1L, 2L, 3L, 4L)) # Here is ylag!
    
    R1_lag <- y_lag[[1L]]
    C1_lag <- y_lag[[2L]]
    R2_lag <- y_lag[[3L]]
    C2_lag <- y_lag[[4L]]
  
    c(r * R1 * (1 - R1 / k) - x/phi * R1 * C1 - e * R1 + l * R2,
      gamma * x/phi * R1_lag * C1_lag - d * C1 - e * C1 + l * C2,
      r * R2 * (1 - R2 / k) - x/phi * R2 * C2 - e * R2 + l * R1,
      gamma * x/phi * R2_lag * C2_lag - d * C2 - e * C2 + l * C1)
  }
  
# RC model plot
y0 <- c(1, 1, 1, 1)
tt <- seq(0, 365, length.out = 100)
yy <- dde::dopri(y0, tt, RC, NULL, n_history = 1000L, return_history = FALSE)
plot(yy[,2],type='l')
plot(yy[,3],type='l')
plot(yy[,4],type='l')
plot(yy[,5],type='l')
```