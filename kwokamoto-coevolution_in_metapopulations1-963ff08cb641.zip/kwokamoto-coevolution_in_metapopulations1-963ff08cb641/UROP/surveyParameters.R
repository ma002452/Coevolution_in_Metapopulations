source("RCmodel_inputs")

scenario <- c(1,2)

k <- c(1, 10, 100)
x <- c(1, 10, 100)
phi <- c(1, 10, 100)
gamma <- c(0.1, 1, 10)
t_latent <- c(0.2, 1, 100)
d <- c(0.01, 0.1, 10)

K_modifier <- c(1, 10, 100)
w <- c(1, 10, 100)

sc_host <- c(1, 10, 100)
sc_path <- c(1, 10, 100)
resource_diff <- seq(1.1, 25, length=4)
R <- c(0.5, 50, 100)
c_e <- gamma
migration_rate <- c(1, 10, 100)
mutRate <- c(10^(-4), 0.1, 1)

parametersCombos <- expand.grid(scenario, k, x, phi, gamma, t_latent, d, K_modifier, w, sc_host,
                                sc_path, resource_diff, R, c_e, migration_rate, mutRate)
colnames(parametersCombos) <- c('scenario', 'k', 'x', 'phi', 'gamma', 't_latent', 'd', 'K_modifier', 'w',
                                'sc_host', 'sc_path', 'resource_diff', 'R', 'c_e', 'migration_rate', 'mutRate')

# record of the last line of yy table for each parameter combination
finalPopSize = data.frame(R1_1=double(),R2_1=double(),R1_2=double(),R2_2=double(),
                          C1_1=double(),C2_1=double(),C1_2=double(),C2_2=double())
colnames(finalPopSize) <- c('R1_1','R2_1','R1_2','R2_2','C1_1','C2_1','C1_2','C2_2')

for (i in 1:nrow(parametersCombos)) {
  scenario <- parametersCombos[i,1]
  k <- parametersCombos[i,2]
  x <- parametersCombos[i,3]
  phi <- parametersCombos[i,4]
  gamma <- parametersCombos[i,5]
  t_latent <- parametersCombos[i,6]
  d <- parametersCombos[i,7]
  K_modifier <- parametersCombos[i,8]
  w <- parametersCombos[i,9]
  sc_host <- parametersCombos[i,10]
  sc_path <- parametersCombos[i,11]
  resource_diff <- parametersCombos[i,12]
  R <- parametersCombos[i,13]
  c_e <- parametersCombos[i,14]
  migration_rate <- parametersCombos[i,15]
  mutRate <- parametersCombos[i,16]
  
  source("RCmodel.R")
  finalPopSize = rbind(finalPopSize, yy[100,2:9])
}
