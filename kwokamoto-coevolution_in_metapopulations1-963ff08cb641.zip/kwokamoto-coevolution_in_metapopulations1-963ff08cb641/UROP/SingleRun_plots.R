source('simulator_deSolve.R')

summarize <- function(my_matrix)
  {
  r1 <- apply(my_matrix[,2:(1+nPrey_genotypes)]/sum(my_matrix[,2:(1+nPrey_genotypes)])*(1:10), 1, mean)
  r2 <- apply(my_matrix[,(2+nPrey_genotypes):(2*nPrey_genotypes+2)]/sum(my_matrix[,(2+nPrey_genotypes):(2*nPrey_genotypes+2)])*(1:10), 1, mean)
  c1 <- apply(my_matrix[,(3+2*nPrey_genotypes):(3+2*nPrey_genotypes+nPred_genotypes)]/sum(my_matrix[,(3+2*nPrey_genotypes):(3+2*nPrey_genotypes+nPred_genotypes)])*(1:10), 1, mean)
  c2 <-  apply(my_matrix[,(4+2*nPrey_genotypes+nPred_genotypes):(2*nPrey_genotypes+2*nPred_genotypes+1)]/sum(my_matrix[,(4+2*nPrey_genotypes+nPred_genotypes):(2*nPrey_genotypes+2*nPred_genotypes+1)])*(1:10), 1, mean)
  return(cbind(r1,r2,c1,c2))
  }

plot_rez <- function(my_matrix)
  {
  otcm <- summarize(my_matrix)
  plot(my_matrix[,1],otcm[,'r1'],t='l',xlab='time',main='resource 1')
  plot(my_matrix[,1],otcm[,'r2'],t='l',xlab='time',main='resource 2')
  plot(my_matrix[,1],otcm[,'c1'],t='l',xlab='time',main='consumer 1')
  plot(my_matrix[,1],otcm[,'c2'],t='l',xlab='time',main='consumer 2')
  }

par(mfrow=c(2,2),mar=rep(2,4))
plot_rez(yy)

# for population dynamics:
plot(apply(yy[,(3+2*nPrey_genotypes):(3+2*nPrey_genotypes+nPred_genotypes)],1,sum),t='l',col="RED")
par(new=T)
plot(apply(yy[,2:(nPrey_genotypes + 1)],1,sum),t='l')
