source("dde_function_deSolve.R")
source("aux_equations.R")

# plot model
y0 <- c(0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,
        0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,
        0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,
        0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1) # initial dR should be < carrying capacity

tmax <- 700
tt <- seq(0, tmax, length.out = 1000)

ext_threshold <- .Machine$double.eps

eventfun <- function(t, y, parms){
  with(as.list(y), {
    y[y < ext_threshold] <- 0
    return(y)
  })
}

yy <- deSolve::dede(y0, tt, RC, as.list(y0),method='bdf')

colnames(yy) <- c('t', paste('R',1:nPred_genotypes,'_',1,sep=''), paste('R',1:nPred_genotypes,'_',2,sep=''), paste('C',1:nPred_genotypes,'_',1,sep=''), paste('C',1:nPred_genotypes,'_',2,sep=''))