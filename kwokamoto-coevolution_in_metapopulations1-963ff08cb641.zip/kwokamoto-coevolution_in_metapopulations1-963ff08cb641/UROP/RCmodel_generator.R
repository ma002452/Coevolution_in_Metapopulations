source('RCmodel_inputs')
source("aux_equations.R") # you might not even need this
source("consumer_mutations_in.R")

# create a table for all resource combos (ith prey/pred, jth patch)
spp <- 0 # resource
i <- 1:nPrey_genotypes
j <- 1:nPatches
Rcombos <- expand.grid(spp,i,j)
colnames(Rcombos) <- c('spp','i','j')
# create a table for all consumer combos (ith prey/pred, jth patch)
spp <- 1 # consumer
i <- 1:nPred_genotypes
Ccombos <- expand.grid(spp,i,j)
colnames(Ccombos) <- c('spp','i','j')
# merge Rcombos and Ccombos
combos <- rbind(Rcombos, Ccombos)

writePrey <- function(i,k) #for the ith prey genotype in the kth patch
{
  mutation_rate <- paste('1-(',
                         paste(paste('mu(',i,',',(1:nPrey_genotypes),')',sep=''),sep='',collapse='+'),
                         ')',sep='')
  encounters <- paste('r(',i,')*R',i,'_',k,'*(1-(',
                      paste(paste('R',1:nPrey_genotypes,'_',k,sep=''),sep='',collapse='+'),
                      ')/K(',k,')))-R',i,'_',k,'*(',
                      paste(paste('ar(',1:nPred_genotypes,',',i,')*C',1:nPred_genotypes,'_',k,sep=''),sep='',collapse='+'),
                      ')',sep='')
  
  
  migrations_in <- paste(paste('R',i,'_',(1:nPatches),'*m(',(1:nPatches),',',k,')',sep=''),collapse='+',sep='')
  migrations_out <- paste('R',i,'_',k,'*(',
                          paste(paste('m(',k,',',(1:nPatches),')',sep=''),collapse='+',sep=''),
                          ')',sep='')
  
  
  mutations_in <- paste('(1-(',
                        paste(paste('R',1:nPrey_genotypes,'_',k,sep=''),collapse='+',sep=''),
                        ')/K(',k,'))*(',
                        paste(paste('r(',1:nPrey_genotypes,')*R',1:nPrey_genotypes,'_',k,'*mu(',1:nPrey_genotypes,',',i,')',sep=''),collapse='+',sep=''),
                        ')',sep='')
  
  
  cat('dR',i,'_',k,' <- (',mutation_rate,')*(',encounters,'+(',migrations_in,')-(',migrations_out,')+(',mutations_in,')\n',sep='',collapse='')
}

writePred <- function(j,k) #for the jth pred genotype in the kth patch
{
  encounters <- paste('e(',j,')*C',j,'_',k,'_lag*(',
                      paste(paste('R',1:nPrey_genotypes,'_',k,'_lag*ar(',j,',',1:nPrey_genotypes,')',sep=''),collapse='+',sep=''),
                      ')*(1-(',
                      paste(paste('mu(',j,',',1:nPred_genotypes,')',sep=''),collapse='+',sep=''),
                      '))-W(',j,')*C',j,'_',k,sep='')
  
  
  migrations_in <- paste(paste('C',j,'_',1:nPatches,'*m(',1:nPatches,',',k,')',sep=''),collapse='+',sep='')
  migrations_out <- paste('C',j,'_',k,'*(',
                          paste(paste('m(',k,',',1:nPatches,')',sep=''),collapse='+',sep=''),
                          ')',sep='')
  
  
  mutations_in <- muts_in(j,k) # from the consumer_mutations_in.R file
  
  
  cat('dC',j,'_',k,' <- (',encounters,')+(',migrations_in,')-(',migrations_out,')+(',mutations_in,')\n',sep='',collapse='')
}

sink(file='dde_function.R')
# Opening line of RC function:
cat('RC <- function(t, y, p) \n{\n')

# time delays
# -------------------------------------------------------------------------------------------------------------------------
# generate Rs
# copy the output and paste it inside the RC function
for (j in 1:nPatches) {
  for (i in 1:nPrey_genotypes) {
    LHS <- paste('R',i,'_',j,sep='')
    RHS <- paste('y[[',which(combos$spp == 0 & combos$i == i & combos$j == j),'L]]\n',sep='')
    cat(LHS,RHS,sep=' <- ')
  }
}

# generate Cs
# copy the output and paste it inside the RC function
for (j in 1:nPatches){
  for (i in 1:nPred_genotypes) {
    LHS <- paste('C',i,'_',j,sep='')
    RHS <- paste('y[[',which(combos$spp == 1 & combos$i == i & combos$j == j),'L]]\n',sep='')
    cat(LHS,RHS,sep=' <- ')
  }
}

# generate y_lag
# copy the output and paste it inside the RC function
Ls <- ''
for (i in 1:nrow(combos)) {
  temp_Ls <- paste(i,'L,',sep='')
  Ls <- paste(Ls,temp_Ls,sep='')
}
Ls <- substr(Ls, 1, nchar(Ls)-1)
cat('\ntau <- t - t_latent\n')
cat("y_lag <- dde::ylag(tau, c(",Ls,"))",'\n\n')

# generate R_lags
# copy the output and paste it inside the RC function
for (j in 1:nPatches) {
  for (i in 1:nPrey_genotypes) {
    LHS <- paste('R',i,'_',j,'_lag',sep='')
    RHS <- paste('y_lag[[',which(combos$spp == 0 & combos$i == i & combos$j == j),'L]]\n',sep='')
    cat(LHS,RHS,sep=' <- ')
  }
}

# generate C_lags
# copy the output and paste it inside the RC function
for (j in 1:nPatches){
  for (i in 1:nPred_genotypes) {
    LHS <- paste('C',i,'_',j,'_lag',sep='')
    RHS <- paste('y_lag[[',which(combos$spp == 1 & combos$i == i & combos$j == j),'L]]\n',sep='')
    cat(LHS,RHS,sep=' <- ')
  }
}

# generate dRs
# copy the output and paste it inside the RC function
for (j in 1:nPatches){
  for (i in 1:nPrey_genotypes) {
    writePrey(i,j)
  }
}

# generate dCs
# copy the output and paste it inside the RC function
for (j in 1:nPatches){
  for (i in 1:nPred_genotypes) {
    writePred(i,j)
  }
}

# generate a series of dRs and dCs
# copy the output and paste it into c() in the RC function
result <- ''
for (i in 1:nrow(combos)) {
  if (combos[i,]$spp == 0) {
    input <- paste('dR',combos[i,]$i,'_',combos[i,]$j,sep='')
  } else {
    input <- paste('dC',combos[i,]$i,'_',combos[i,]$j,sep='')
  }
  result <- paste(result,input,sep=',')
}

result <- substr(result, 2, nchar(result))
# book end result:
result <- paste('c(',result,')',sep='')
cat(result)
cat('\n}') # Close the RC function
closeAllConnections() # end the file outputting; release the sink destination