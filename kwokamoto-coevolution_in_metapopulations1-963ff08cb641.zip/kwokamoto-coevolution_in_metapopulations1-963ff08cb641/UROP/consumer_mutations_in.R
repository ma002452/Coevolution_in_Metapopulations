permutes <- expand.grid(1:nPrey_genotypes, 1:nPred_genotypes)

# for the jth consumer genotype in the kth patch
muts_in <- function(j,k)
{
  interacts <- c()
  for (i in 1:nrow(permutes))
  {
    interacts[i] <- paste('ar(',permutes[i,2], ',',permutes[i,1],')*C',permutes[i,2],'_',k,'_lag*R',permutes[i,1],'_',k,'_lag',sep='')
  }
  
  sum_encs <- c()
  for (i in 1:nPred_genotypes)
    sum_encs[i] <- paste('(',paste((interacts[((i-1)*nPrey_genotypes+1):(i*nPrey_genotypes)]),collapse='+'),')',sep='')
  
  births <- paste(paste('e(',1:nPred_genotypes,')',sep=''), sum_encs, sep='*')
  
  mutations_in <- paste(paste(births,paste('mu(',1:nPred_genotypes,',',j,')',sep=''),sep='*'),collapse='+')
  return(mutations_in)
}
