source("dde_function.R")
source("RCmodel_inputs")

# plot model
y0 <- c(0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,
        0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,
        0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,
        0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1) # initial dR should be < carrying capacity

tmax <- 3000
tt <- seq(0, tmax, length.out = 1000)

ext_threshold <- .Machine$double.eps

eventfun <- function(t, y, parms){
  with(as.list(y), {
    y[y < ext_threshold] <- 0
    return(y)
  })
}

yy <- dde::dopri(y0, tt, RC, numeric(0), n_history = 1000L, return_history = FALSE, return_statistics=TRUE,step_size_min_allow=TRUE, step_size_min=0,method='dopri853', event_function=eventfun, event_time=seq(0,tmax/2,length=100))

