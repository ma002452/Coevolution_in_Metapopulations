source('RCmodel_inputs')

# This 'ar' function will be used in place of chi(pred_genotype)/gamma(prey_genotype) or chi(pred_genotype)/phi(prey_genotype)
# Probability of successful infection (attack rates):
# 1) phenotype matching model, 2) phenotype escalation model
ar <- function (parasite_genotype, host_genotype) {
  if (scenario == 1) {return (exp(-alpha*(host_genotype-parasite_genotype)^2))} #phenotype matching model
  else {return (1/(1+exp(alpha*(host_genotype-parasite_genotype))))} #phenotype escalation model
}

# This can be visualized with:
# persp(x=1:10,y=1:10,z=outer(1:10,1:10,ar),phi=25,theta=-50)

# notes:
# 3) match wordings with RCmodel.R (e.g. substitute host_genotype with i, and so on)
# Host tradeoff
cR <- function(x) (exp(1)-exp(x^(1/sc_host))) / (exp(1)- 1) # scaled to go between 0,1
# R <- c(0.5,resource_diff*0.5)
r <- function(host_genotype)
{
  return(R*cR((host_genotype-1)/(nPrey_genotypes-1)))
}


# notes:
# 3) match wordings with RCmodel.R (e.g. substitute pathogen_genotype with j, and so on)
# pathogen tradeoff
cA <- function(x) (exp(1)-exp(x^(1/sc_path))) / (exp(1)- 1) # scaled to go between 0,1
e <- function(pathogen_genotype)
{
  return(c_e * cA((pathogen_genotype-1)/(nPred_genotypes-1)))
}


# notes:
# 3) match wordings with RCmodel.R (e.g. substitute patch_1 with k1?, and so on)
# migration rates; same for both path/host
m <- function(patch_1, patch_2)
{
  return(migration_rate)
}


# notes:
# 2) match wordings with RCmodel.R (e.g. substitute genotype_1 with i and genotype_2 with j, and so on)
# mutation rates; same for both path/host
mu <- function(genotype_1, genotype_2)
{
  return(ifelse(genotype_1==genotype_2, 0, mutRate^(abs(genotype_1 - genotype_2))))
}


# temporary function for K
# parameter k indicates patch_num
K <- function(k)
{
  ifelse(k == 1, carrying_capacity, K_modifier*carrying_capacity)
}


# temporary function for W
# parameter j indicates pred_genotype
W <- function(j) w
