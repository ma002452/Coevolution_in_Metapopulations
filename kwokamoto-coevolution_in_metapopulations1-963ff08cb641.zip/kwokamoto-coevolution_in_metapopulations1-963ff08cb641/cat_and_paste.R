# trade-off function
x_max <- 10
y_max <- 10

tradeoff <- function(x) {
  y_max * (exp(1)-exp((x/x_max)^(1/sc))) / (exp(1)- 1)
}
	
sc_s <- 10^seq(-5,2,length=10)
for (i in 1:10) {
	sc <- sc_s[i]
	if (i==1) {
		plot(tradeoff,0, x_max)
	}
	else {
	lines(seq(0,x_max,length=100), tradeoff(seq(0,x_max,length=100)), lty=i)
	}
}
sc <- 1 #  a special case with a near-linear tradeoff
lines(seq(0,x_max,length=100), tradeoff(seq(0,x_max,length=100)), lty=i + 1)


# nPatches, nPrey_genotypes, nPred_genotypes
prey_ngenotypes <- 10
pred_ngenotypes <- 10
num_islands <- 2


# RC model
check_phi <- function(Phi) {
  RC <- function(t, y, p) {
    k <- 0.5
    x <- 0
    phi <- Phi
    r <- tradeoff(phi)
    gamma <- 0.5
    t_latent <- 5
    d <- 0.1
    e <- 0.5
    l <- 0.5
    
    cat(paste('R', 1:(num_islands*prey_ngenotypes), ' <- y[[', seq(1, num_islands*(prey_ngenotypes+pred_ngenotypes), by=2), 'L]]\n', sep=''))
    cat(paste('C', 1:(num_islands*pred_ngenotypes), ' <- y[[', seq(2, num_islands*(prey_ngenotypes+pred_ngenotypes), by=2), 'L]]\n', sep=''))
    #R1 <- y[[1L]]
    #C1 <- y[[2L]]
    #R2 <- y[[3L]]
    #C2 <- y[[4L]]
  
    tau <- t - t_latent
    y_lag <- dde::ylag(tau, cat(paste(1:(num_islands*(prey_ngenotypes+pred_ngenotypes)),'L,', sep='')))
    #y_lag <- dde::ylag(tau, c(1L, 2L, 3L, 4L)) # Here is ylag!
    
    cat(paste('R', 1:(num_islands*prey_ngenotypes), '_lag <- y_lag[[', seq(1, num_islands*(prey_ngenotypes+pred_ngenotypes), by=2),'L]]\n',sep=''))
    cat(paste('C', 1:(num_islands*pred_ngenotypes), '_lag <- y_lag[[', seq(2, num_islands*(prey_ngenotypes+pred_ngenotypes), by=2),'L]]\n',sep=''))
    #R1_lag <- y_lag[[1L]]
    #C1_lag <- y_lag[[2L]]
    #R2_lag <- y_lag[[3L]]
    #C2_lag <- y_lag[[4L]]
  
    c(r * R1 * (1 - R1 / k) - x/phi * R1 * C1 - e * R1 + l * R2,
      gamma * x/phi * R1_lag * C1_lag - d * C1 - e * C1 + l * C2,
      r * R2 * (1 - R2 / k) - x/phi * R2 * C2 - e * R2 + l * R1,
      gamma * x/phi * R2_lag * C2_lag - d * C2 - e * C2 + l * C1)
  }
  
  # RC model plot
  y0 <- c(1, 0, 1, 1)
  tt <- seq(0, 365, length.out = 100)
  yy <- dde::dopri(y0, tt, RC, NULL, n_history = 1000L, return_history = FALSE)
  plot(yy[,5],type='l')
}


# trying to plot the RC model automatically using the for loop depending on the value of phi
for (i in seq(from=1, to=2, by=0.2)) {
  check_phi(i)
}
par(mfrow=c(2,2))