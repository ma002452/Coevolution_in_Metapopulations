require(deSolve)

nPrey_genotypes <- 2
nPred_genotypes <- 2
nPatches <- 2

writePrey <- function(i,j) #For the ith host genotype in the jth patch.
{
  encounters <- paste(paste('-a(',1:nPred_genotypes,',',i,')*C',paste(1:nPred_genotypes,j,sep="_"),'*R',i,'_',j,sep=""),collapse="")
  density_dependence <- paste('-R',1:nPrey_genotypes,'_',j,'/k[',j,']',sep="",collapse='')
  mutations_in <-
    paste('+', paste('mu(',1:nPrey_genotypes, ',',i,')*r(',1:nPrey_genotypes,',',j,')*R',1:nPrey_genotypes,'_',j,'*(1',density_dependence,')',sep='',collapse='+'))
  mutations_out <-
    paste('mu(',i, ',',1:nPrey_genotypes,')',sep='',collapse='+')
  
  migrations <- paste(paste('-m(',j,',',1:nPatches,')*R',i,'_',j,sep=""),
                      paste('+m(',1:nPatches,',',j,')*R',i,'_',1:nPatches,sep=""),
                      collapse='')
  cat(paste('dR',i,'_',j,' <- (1-(',mutations_out,'))*r(',i,',',j,')*R',i,'_',j,'*(1',density_dependence,')', encounters, mutations_in, migrations , sep="",collapse=""))
}

writePred <- function(i,j) #For the ith pathogen genotype in the jth patch.
{
  encounters <- paste('a(',i,',',1:nPrey_genotypes,')','*C',i,'_',j,
                      paste('*R',1:nPrey_genotypes,'_',j,sep=""),collapse="+",sep="")
  mutations <- paste(paste('-mu(',i,',',1:nPred_genotypes,')*C',i,'_',j,sep=""),
                     paste('+mu(',1:nPred_genotypes,',',i,')*C',(1:nPred_genotypes),'_',j,sep=""),
                     collapse="")
  migrations <- paste(paste('-m(',j,',',1:nPatches,')*C',i,'_',j,sep=""),
                      paste('+m(',1:nPatches,',',j,')*C',i,'_',1:nPatches,sep=""),
                      collapse='')
  cat(paste('dC',i,'_',j,' <- e(',i,',',j,')*(', encounters,')', mutations, migrations , '-w*C',i,'_',j, sep="",collapse=""))
}

preyByPatch <- cbind(rep("dR",nPrey_genotypes * nPatches),expand.grid(1:nPrey_genotypes,'_', 1:nPatches))
predByPatch <- cbind(rep("dC",nPred_genotypes * nPatches),expand.grid(1:nPred_genotypes,'_', 1:nPatches))

listVars <- c(apply(preyByPatch,1,paste,collapse=""), apply(predByPatch,1,paste,collapse=""))
listVars <- gsub(" ","",listVars)
cat(paste("c(",paste(listVars,collapse=","),")",sep=""))


invals <- paste(paste(listVars,collapse="=0,"),"=0",sep="")
invals <- gsub("d","",invals)
for (i in 1:nPatches)
{
  invals <- gsub(paste("R1","_",i,"=0",sep=""),paste("R1","_",i,"=1",sep=""),invals)
  invals <- gsub(paste("C1","_",i,"=0",sep=""),paste("C1","_",i,"=0.001",sep=""),invals)
}


for (i in 1:nPrey_genotypes)
{
  cat(writePrey(i,1),"\n")
  cat(writePrey(i,2),"\n")
}
for (i in 1:nPred_genotypes)
{
  cat(writePred(i,1),"\n")
  cat(writePred(i,2),"\n")
}


# initial values:
invals <- paste(paste(listVars,collapse="=0,"),"=0",sep="")
invals <- gsub("R1_1=0","R1_1=1",invals)
invals <- gsub("C1_1=0","C1_1=0.01",invals)